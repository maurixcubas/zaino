from config import db

products_collection = db["products"]
sections_collection = db["sections"]